# ============================================================
#   JARVIS - Dina Wala (Aura 99999+ Edition)
#   Full UI + AI (Groq) + Voice + Commands + Memory
# ============================================================

import os
import json
import threading
import platform
import subprocess
from datetime import datetime

import flet as ft
from dotenv import load_dotenv
from groq import Groq

# ============================================================
#   CONFIG
# ============================================================
try:
    load_dotenv()
except:
    pass

GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")
GROQ_MODEL = "llama-3.3-70b-versatile"

USER_NAME = "Bhai"
USER_CITY = "Dina"
USER_PROJECT = "Bano Qabil"
WAKE_WORD = "hello jarvis"
VOICE_GENDER = "male"
VOICE_LANGUAGE = "ur"
MEMORY_FILE = "memory.json"

SYSTEM_PROMPT = f"""Tum JARVIS ho, ek smart AI assistant jo {USER_NAME} ka dost hai.
Tum {USER_CITY} se ho aur {USER_PROJECT} ka project ho. Aura 99999+.
Roman Urdu, Urdu, English samajhte ho. Jawab chota aur helpful rakho.
Code maange to full working code with comments do.
Dostana andaz me baat karo. Tumhara naam JARVIS hai, Dina Wala."""

SYSTEM = platform.system()
IS_MOBILE = "ANDROID_ROOT" in os.environ or "ANDROID_DATA" in os.environ

# ============================================================
#   THEME COLORS
# ============================================================
BG_DARK = "#0a0e1a"
BG_MID = "#0f1428"
BG_LIGHT = "#141833"
BG_HOVER = "#1a2040"
ACCENT = "#00d4ff"
ACCENT_DIM = "#0e7490"
SUCCESS = "#4ade80"
DANGER = "#ff4757"
WARNING = "#fbbf24"
TEXT_MAIN = "#e6edf7"
TEXT_DIM = "#7f8ea3"
TEXT_MUTED = "#4a5568"
USER_BUBBLE = "#1e3a8a"
BOT_BUBBLE = "#141b2d"

# ============================================================
#   BRAIN (Groq)
# ============================================================
class JarvisBrain:
    def __init__(self):
        self.client = None
        self.messages = []
        self._load_memory()
        self._init_groq()

    def _init_groq(self):
        try:
            if not GROQ_API_KEY:
                raise Exception("GROQ_API_KEY missing")
            self.client = Groq(api_key=GROQ_API_KEY)
            self.messages = [{"role": "system", "content": SYSTEM_PROMPT}] + self.messages
            print("[Brain] Groq connected ✅")
        except Exception as e:
            print(f"[Brain] Init error: {e}")
            self.client = None

    def _load_memory(self):
        if os.path.exists(MEMORY_FILE):
            try:
                with open(MEMORY_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    self.messages = data.get("messages", [])
            except:
                self.messages = []

    def _save_memory(self):
        try:
            chat_only = [m for m in self.messages if m["role"] != "system"][-20:]
            with open(MEMORY_FILE, "w", encoding="utf-8") as f:
                json.dump({"messages": chat_only}, f, ensure_ascii=False, indent=2)
        except:
            pass

    def ask(self, user_message: str) -> str:
        if not user_message.strip():
            return "Kuch bolo to sahi bhai 😄"
        if self.client is None:
            return self._offline(user_message)
        try:
            self.messages.append({"role": "user", "content": user_message})
            response = self.client.chat.completions.create(
                model=GROQ_MODEL,
                messages=self.messages,
                temperature=0.7,
                max_tokens=1024,
                top_p=0.9,
            )
            reply = response.choices[0].message.content.strip()
            self.messages.append({"role": "assistant", "content": reply})
            self._save_memory()
            return reply
        except Exception as e:
            if len(self.messages) > 25:
                self.messages = [self.messages[0]] + self.messages[-20:]
            return f"API error: {str(e)[:100]}"

    def _offline(self, msg):
        m = msg.lower()
        if any(w in m for w in ["hello", "salam", "hi"]):
            return "Walaikum Salam! JARVIS offline mode me hai."
        if "time" in m or "waqt" in m:
            return f"Abhi {datetime.now().strftime('%I:%M %p')} baje."
        if "date" in m:
            return f"Aaj {datetime.now().strftime('%d %B %Y')} hai."
        return "Net issue hai bhai. Basic commands try karo."

    def clear_memory(self):
        self.messages = [{"role": "system", "content": SYSTEM_PROMPT}]
        self._save_memory()

# ============================================================
#   VOICE
# ============================================================
try:
    import speech_recognition as sr
    import pyttsx3
    VOICE_AVAILABLE = True
except Exception as e:
    print(f"[Voice] missing: {e}")
    VOICE_AVAILABLE = False


class VoiceOutput:
    def __init__(self):
        if not VOICE_AVAILABLE:
            return
        try:
            self.engine = pyttsx3.init()
            voices = self.engine.getProperty("voices")
            if voices:
                idx = 1 if (VOICE_GENDER == "female" and len(voices) > 1) else 0
                self.engine.setProperty("voice", voices[idx].id)
                self.engine.setProperty("rate", 175)
        except Exception as e:
            print(f"[TTS] {e}")

    def speak(self, text):
        if not VOICE_AVAILABLE or not text:
            return
        try:
            self.engine.say(text)
            self.engine.runAndWait()
        except Exception as e:
            print(f"[TTS] {e}")


class VoiceInput:
    def __init__(self):
        if not VOICE_AVAILABLE:
            return
        self.recognizer = sr.Recognizer()
        self.recognizer.energy_threshold = 300
        self.recognizer.dynamic_energy_threshold = True

    def listen(self, timeout=5, phrase_limit=8):
        if not VOICE_AVAILABLE:
            return ""
        try:
            with sr.Microphone() as source:
                self.recognizer.adjust_for_ambient_noise(source, duration=0.5)
                audio = self.recognizer.listen(source, timeout=timeout, phrase_time_limit=phrase_limit)
            for lang in ["ur-PK", "en-US", "hi-IN"]:
                try:
                    return self.recognizer.recognize_google(audio, language=lang)
                except sr.UnknownValueError:
                    continue
                except sr.RequestError:
                    return ""
            return ""
        except sr.WaitTimeoutError:
            return ""
        except Exception as e:
            print(f"[STT] {e}")
            return ""

# ============================================================
#   COMMANDS
# ============================================================
APP_MAP = {
    "chrome": {"Windows": "chrome", "Linux": "google-chrome", "android": "com.android.chrome"},
    "vscode": {"Windows": "code", "Linux": "code", "android": None},
    "whatsapp": {"Windows": "whatsapp", "Linux": "whatsapp", "android": "com.whatsapp"},
    "notepad": {"Windows": "notepad", "Linux": "gedit", "android": None},
    "calculator": {"Windows": "calc", "Linux": "gnome-calculator", "android": "com.android.calculator2"},
}


def open_app(app_name):
    app_name = app_name.lower().strip()
    if app_name not in APP_MAP:
        return f"'{app_name}' list me nahi"
    cmd = APP_MAP[app_name].get(SYSTEM)
    if not cmd:
        return f"'{app_name}' is system par nahi"
    try:
        if IS_MOBILE:
            subprocess.Popen(["am", "start", "-n", cmd])
        elif SYSTEM == "Windows":
            os.startfile(cmd)
        elif SYSTEM == "Darwin":
            subprocess.Popen(["open", "-a", cmd])
        else:
            subprocess.Popen([cmd])
        return f"'{app_name}' khol diya ✅"
    except Exception as e:
        return f"Error: {e}"


def close_app(app_name):
    app_name = app_name.lower().strip()
    try:
        if SYSTEM == "Windows":
            subprocess.run(["taskkill", "/F", "/IM", f"{app_name}.exe"], capture_output=True)
        else:
            subprocess.run(["pkill", "-f", app_name], capture_output=True)
        return f"'{app_name}' band ✅"
    except Exception as e:
        return f"Error: {e}"


def set_volume(level):
    try:
        if SYSTEM == "Windows":
            from ctypes import cast, POINTER
            from comtypes import CLSCTX_ALL
            from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
            devices = AudioUtilities.GetSpeakers()
            interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
            volume = cast(interface, POINTER(IAudioEndpointVolume))
            volume.SetMasterVolumeLevelScalar(level / 100.0, None)
        elif SYSTEM == "Linux":
            subprocess.run(["amixer", "-D", "pulse", "sset", "Master", f"{level}%"], capture_output=True)
        return f"Volume {level}% ✅"
    except Exception as e:
        return f"Volume error: {e}"


def set_brightness(level):
    try:
        import screen_brightness_control as sbc
        sbc.set_brightness(level)
        return f"Brightness {level}% ✅"
    except Exception as e:
        return f"Brightness error: {e}"


def shutdown(minutes=1):
    try:
        if SYSTEM == "Windows":
            subprocess.run(["shutdown", "/s", "/t", str(minutes * 60)])
        else:
            subprocess.run(["shutdown", "-h", f"+{minutes}"])
        return f"System {minutes} min me shutdown"
    except Exception as e:
        return f"Error: {e}"


def gaming_mode():
    try:
        if SYSTEM == "Windows":
            subprocess.run([
                "powershell", "-Command",
                "Set-ItemProperty -Path 'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\PushNotifications' -Name 'ToastEnabled' -Value 0"
            ], capture_output=True)
            subprocess.run(["powercfg", "/setactive", "SCHEME_MIN"], capture_output=True)
        return "Gaming Mode ON 🎮"
    except Exception as e:
        return f"Error: {e}"


def get_time():
    return f"Abhi {datetime.now().strftime('%I:%M %p')} baje hain"


def get_date():
    return f"Aaj {datetime.now().strftime('%d %B %Y')}, {datetime.now().strftime('%A')}"


def process_command(text):
    t = text.lower().strip()
    if any(w in t for w in ["time kya", "kitne baje", "what time"]):
        return get_time()
    if any(w in t for w in ["date kya", "tareekh", "what date"]):
        return get_date()
    if t.startswith("kholo ") or t.startswith("open "):
        return open_app(t.split(maxsplit=1)[1].replace("karo", "").strip())
    if "chrome kholo" in t or "open chrome" in t:
        return open_app("chrome")
    if "vscode kholo" in t or "code kholo" in t:
        return open_app("vscode")
    if "whatsapp kholo" in t:
        return open_app("whatsapp")
    if "calculator kholo" in t:
        return open_app("calculator")
    if t.startswith("band karo ") or "close " in t:
        for app in APP_MAP:
            if app in t:
                return close_app(app)
    if "volume" in t and any(w in t for w in ["tez", "high", "up", "badha"]):
        return set_volume(80)
    if "volume" in t and any(w in t for w in ["kam", "low", "down"]):
        return set_volume(25)
    if "mute" in t:
        return set_volume(0)
    if "brightness" in t and any(w in t for w in ["tez", "high"]):
        return set_brightness(90)
    if "brightness" in t and any(w in t for w in ["kam", "low"]):
        return set_brightness(30)
    if "shutdown" in t and "cancel" not in t:
        return shutdown(1)
    if "gaming mode" in t:
        return gaming_mode()
    return None

# ============================================================
#   STATE + SINGLETONS
# ============================================================
class AppState:
    def __init__(self):
        self.voice_mode = False
        self.continuous_listen = False
        self.stop_listen = False
        self.current_tab = 0

state = AppState()
brain = JarvisBrain()
tts = VoiceOutput() if VOICE_AVAILABLE else None
stt = VoiceInput() if VOICE_AVAILABLE else None

# ============================================================
#   UI HELPERS
# ============================================================
def _card(content, padding=15, bg=BG_MID, border_radius=14):
    return ft.Container(
        content=content, padding=padding, bgcolor=bg,
        border_radius=border_radius,
        border=ft.border.all(1, "#1f2947"),
    )


def _stat_tile(icon, label, value, color=ACCENT):
    return ft.Container(
        content=ft.Column([
            ft.Icon(icon, color=color, size=22),
            ft.Text(value, size=16, weight=ft.FontWeight.BOLD, color=TEXT_MAIN),
            ft.Text(label, size=10, color=TEXT_DIM),
        ], spacing=3, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
        padding=12, bgcolor=BG_LIGHT, border_radius=12,
        border=ft.border.all(1, "#1f2947"),
        expand=True,
    )

# ============================================================
#   MAIN APP
# ============================================================
def main(page: ft.Page):
    page.title = "JARVIS - Dina Wala"
    page.theme_mode = ft.ThemeMode.DARK
    page.bgcolor = BG_DARK
    page.padding = 0
    page.window_width = 900
    page.window_height = 720
    page.window_min_width = 420
    page.window_min_height = 600

    # ===== SIDEBAR =====
    nav_items_data = [
        ("Chat", ft.icons.CHAT_BUBBLE_OUTLINE, 0),
        ("Commands", ft.icons.TERMINAL, 1),
        ("Settings", ft.icons.SETTINGS_OUTLINED, 2),
        ("About", ft.icons.INFO_OUTLINE, 3),
    ]

    nav_buttons = []

    def build_nav(idx, name, icon):
        active = idx == state.current_tab
        btn = ft.Container(
            content=ft.Row([
                ft.Icon(icon, size=18, color=ACCENT if active else TEXT_DIM),
                ft.Text(name, size=13,
                        color=ACCENT if active else TEXT_DIM,
                        weight=ft.FontWeight.BOLD if active else ft.FontWeight.NORMAL),
            ], spacing=10),
            padding=ft.padding.symmetric(horizontal=14, vertical=11),
            border_radius=10,
            bgcolor=BG_HOVER if active else "transparent",
            on_click=lambda e, i=idx: switch_tab(i),
            ink=True,
        )
        return btn

    def refresh_nav():
        nav_col.controls.clear()
        for idx, name, icon in nav_items_data:
            nav_col.controls.append(build_nav(idx, name, icon))
        page.update()

    nav_col = ft.Column(spacing=4, controls=[])

    sidebar = ft.Container(
        content=ft.Column([
            ft.Row([
                ft.Container(
                    content=ft.Icon(ft.icons.SMART_TOY, color=BG_DARK, size=20),
                    bgcolor=ACCENT, padding=8, border_radius=10,
                ),
                ft.Column([
                    ft.Text("JARVIS", size=16, weight=ft.FontWeight.BOLD, color=TEXT_MAIN),
                    ft.Text("Dina Wala ⚡", size=10, color=TEXT_DIM),
                ], spacing=0),
            ], spacing=10),
            ft.Divider(height=1, color="#1f2947"),
            nav_col,
            ft.Container(expand=True),
            ft.Divider(height=1, color="#1f2947"),
            ft.Container(
                content=ft.Column([
                    ft.Row([
                        ft.Container(width=8, height=8, bgcolor=SUCCESS, border_radius=10),
                        ft.Text("Online", size=11, color=SUCCESS),
                    ], spacing=6),
                    ft.Text("Groq Llama 3.3", size=10, color=TEXT_MUTED),
                    ft.Text(f"v1.0 • {USER_CITY}", size=10, color=TEXT_MUTED),
                ], spacing=3),
                padding=10,
            ),
        ], spacing=12),
        width=200, bgcolor=BG_MID,
        padding=15,
        border=ft.border.only(right=ft.border.BorderSide(1, "#1f2947")),
    )

    # =========================================================
    #   TAB 1: CHAT
    # =========================================================
    chat_list = ft.ListView(expand=True, spacing=10, padding=15, auto_scroll=True)

    welcome_chat = ft.Container(
        content=ft.Column([
            ft.Container(
                content=ft.Icon(ft.icons.SMART_TOY, color=ACCENT, size=40),
                bgcolor=BG_LIGHT, padding=20, border_radius=50,
                border=ft.border.all(2, ACCENT),
            ),
            ft.Text("JARVIS", size=26, weight=ft.FontWeight.BOLD, color=TEXT_MAIN),
            ft.Text("Dina Wala • Aura 99999+", size=12, color=TEXT_DIM),
            ft.Container(
                content=ft.Row([
                    ft.Icon(ft.icons.BOLT, size=12, color=SUCCESS),
                    ft.Text("Groq Llama 3.3 Powered", size=11, color=SUCCESS),
                ], spacing=5, alignment=ft.MainAxisAlignment.CENTER),
                padding=ft.padding.symmetric(horizontal=10, vertical=5),
                bgcolor="#0d2e1a", border_radius=20,
            ),
            ft.Container(height=10),
            ft.Text(f"Salam {USER_NAME}! Kya hukum hai?", size=14, color=TEXT_MAIN),
            ft.Text("Type karo, mic dabao, ya neeche quick commands try karo.", size=11, color=TEXT_DIM),
        ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=8),
        padding=30,
    )

    chat_list.controls.append(welcome_chat)

    def add_bubble(text, is_user=False):
        if is_user:
            bubble = ft.Row([
                ft.Container(expand=True),
                ft.Container(
                    content=ft.Column([
                        ft.Text("You", size=10, color=ACCENT, weight=ft.FontWeight.BOLD),
                        ft.Text(text, size=13, color=TEXT_MAIN, selectable=True),
                        ft.Text(datetime.now().strftime("%I:%M %p"), size=9, color=TEXT_MUTED),
                    ], spacing=3),
                    bgcolor=USER_BUBBLE, padding=12, border_radius=12,
                    margin=ft.margin.only(left=60),
                ),
            ])
        else:
            bubble = ft.Row([
                ft.Container(
                    content=ft.Icon(ft.icons.SMART_TOY, size=16, color=ACCENT),
                    bgcolor=BG_LIGHT, padding=6, border_radius=20,
                ),
                ft.Container(
                    content=ft.Column([
                        ft.Text("JARVIS", size=10, color=ACCENT, weight=ft.FontWeight.BOLD),
                        ft.Text(text, size=13, color=TEXT_MAIN, selectable=True),
                        ft.Text(datetime.now().strftime("%I:%M %p"), size=9, color=TEXT_MUTED),
                    ], spacing=3),
                    bgcolor=BOT_BUBBLE, padding=12, border_radius=12,
                    expand=True,
                ),
            ], spacing=8, vertical_alignment=ft.CrossAxisAlignment.START)
        chat_list.controls.append(bubble)
        page.update()

    def add_system(text):
        chat_list.controls.append(ft.Container(
            content=ft.Text(text, size=11, color=TEXT_DIM, italic=True),
            alignment=ft.alignment.center, padding=6,
        ))
        page.update()

    def send_text(text):
        text = (text or "").strip()
        if not text:
            return
        txt_input.value = ""
        page.update()
        add_bubble(text, is_user=True)
        local_reply = process_command(text)

        def worker():
            reply = local_reply if local_reply else brain.ask(text)
            page.run_thread(lambda: add_bubble(reply))
            if state.voice_mode and tts:
                try:
                    tts.speak(reply)
                except:
                    pass

        threading.Thread(target=worker, daemon=True).start()

    txt_input = ft.TextField(
        hint_text="Message likho...",
        border_radius=25, filled=True, bgcolor=BG_LIGHT,
        border_color=ACCENT_DIM, color=TEXT_MAIN,
        hint_style=ft.TextStyle(color=TEXT_MUTED),
        expand=True, multiline=False,
        on_submit=lambda e: send_text(e.control.value),
    )

    def on_send(e):
        send_text(txt_input.value)

    def on_mic(e):
        if not VOICE_AVAILABLE:
            add_system("Voice modules nahi mile. requirements check karo.")
            return
        if state.continuous_listen:
            state.stop_listen = True
            state.continuous_listen = False
            mic_btn.icon = ft.icons.MIC
            mic_btn.bgcolor = ACCENT
            add_system("Voice mode band")
            return
        state.stop_listen = False
        state.continuous_listen = True
        mic_btn.icon = ft.icons.STOP_CIRCLE
        mic_btn.bgcolor = DANGER
        add_system("Voice mode ON - bolo, main sun raha hoon...")
        page.update()

        def loop():
            while not state.stop_listen:
                t = stt.listen(timeout=3, phrase_limit=6)
                if t:
                    page.run_thread(lambda x=t: send_text(x))
        threading.Thread(target=loop, daemon=True).start()

    def on_clear(e):
        chat_list.controls = [welcome_chat]
        brain.clear_memory()
        page.update()
        add_system("Chat + memory clear ✅")

    def on_voice_toggle(e):
        state.voice_mode = voice_switch.value
        add_system(f"Bolo mode {'ON 🔊' if state.voice_mode else 'OFF 🔇'}")

    mic_btn = ft.ElevatedButton(
        icon=ft.icons.MIC, text="Mic",
        bgcolor=ACCENT, color=BG_DARK,
        on_click=on_mic,
        style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=25)),
    )

    send_btn = ft.IconButton(
        icon=ft.icons.SEND, icon_color=ACCENT, icon_size=26, on_click=on_send,
        style=ft.ButtonStyle(bgcolor=BG_LIGHT, shape=ft.RoundedRectangleBorder(radius=25)),
    )

    clear_btn = ft.IconButton(
        icon=ft.icons.DELETE_OUTLINE, icon_color=DANGER, icon_size=20, on_click=on_clear,
    )

    voice_switch = ft.Switch(value=False, active_color=ACCENT, on_change=on_voice_toggle)

    # Quick command chips
    def quick_chip(label, cmd):
        return ft.Container(
            content=ft.Text(label, size=11, color=ACCENT),
            padding=ft.padding.symmetric(horizontal=12, vertical=7),
            bgcolor=BG_LIGHT, border_radius=20,
            border=ft.border.all(1, ACCENT_DIM),
            on_click=lambda e: send_text(cmd),
            ink=True,
        )

    quick_row = ft.Row([
        quick_chip("⏰ Time", "time kya hua"),
        quick_chip("🌐 Chrome", "chrome kholo"),
        quick_chip("🔊 Volume tez", "volume tez karo"),
        quick_chip("🎮 Gaming", "gaming mode on"),
        quick_chip("💻 VS Code", "vscode kholo"),
    ], spacing=8, scroll=ft.ScrollMode.AUTO, wrap=True)

    chat_tab = ft.Column([
        ft.Container(
            content=ft.Row([
                ft.Column([
                    ft.Text("Chat", size=18, weight=ft.FontWeight.BOLD, color=TEXT_MAIN),
                    ft.Text("Groq Llama 3.3 • Fast replies", size=11, color=TEXT_DIM),
                ], spacing=2),
                ft.Container(expand=True),
                ft.Row([
                    ft.Text("Bolo mode:", size=11, color=TEXT_DIM),
                    voice_switch,
                    clear_btn,
                ], spacing=6),
            ]),
            padding=ft.padding.symmetric(horizontal=20, vertical=12),
            bgcolor=BG_MID,
            border=ft.border.only(bottom=ft.border.BorderSide(1, "#1f2947")),
        ),
        ft.Container(content=chat_list, expand=True),
        ft.Container(
            content=ft.Column([
                quick_row,
                ft.Row([txt_input, send_btn, mic_btn], spacing=8),
            ], spacing=8),
            padding=15,
            bgcolor=BG_MID,
            border=ft.border.only(top=ft.border.BorderSide(1, "#1f2947")),
        ),
    ], spacing=0, expand=True)

    # =========================================================
    #   TAB 2: COMMANDS
    # =========================================================
    def cmd_card(icon, title, desc, cmd):
        return ft.Container(
            content=ft.Column([
                ft.Row([
                    ft.Container(
                        content=ft.Icon(icon, size=18, color=ACCENT),
                        bgcolor=BG_DARK, padding=8, border_radius=8,
                    ),
                    ft.Container(expand=True),
                    ft.Icon(ft.icons.ARROW_FORWARD, size=14, color=TEXT_MUTED),
                ]),
                ft.Text(title, size=13, weight=ft.FontWeight.BOLD, color=TEXT_MAIN),
                ft.Text(desc, size=11, color=TEXT_DIM),
                ft.Container(
                    content=ft.Text(f'"{cmd}"', size=10, color=ACCENT, italic=True),
                    padding=ft.padding.symmetric(horizontal=8, vertical=4),
                    bgcolor=BG_DARK, border_radius=6,
                ),
            ], spacing=8),
            padding=14, bgcolor=BG_MID, border_radius=12,
            border=ft.border.all(1, "#1f2947"),
            on_click=lambda e: send_text(cmd),
            ink=True,
            expand=True,
        )

    commands_grid = ft.Column([
        ft.Text("App Control", size=14, weight=ft.FontWeight.BOLD, color=TEXT_MAIN),
        ft.Row([
            cmd_card(ft.icons.LANGUAGE, "Open Chrome", "Browser", "chrome kholo"),
            cmd_card(ft.icons.CODE, "Open VS Code", "Editor", "vscode kholo"),
            cmd_card(ft.icons.CHAT, "Open WhatsApp", "Chat", "whatsapp kholo"),
        ], spacing=10),
        ft.Container(height=10),
        ft.Text("System Control", size=14, weight=ft.FontWeight.BOLD, color=TEXT_MAIN),
        ft.Row([
            cmd_card(ft.icons.VOLUME_UP, "Volume Up", "80%", "volume tez karo"),
            cmd_card(ft.icons.VOLUME_DOWN, "Volume Down", "25%", "volume kam karo"),
            cmd_card(ft.icons.MUTE, "Mute", "0%", "mute karo"),
        ], spacing=10),
        ft.Row([
            cmd_card(ft.icons.BRIGHTNESS_HIGH, "Brightness Up", "90%", "brightness tez karo"),
            cmd_card(ft.icons.BRIGHTNESS_LOW, "Brightness Down", "30%", "brightness kam karo"),
            cmd_card(ft.icons.SPORTS_ESPORTS, "Gaming Mode", "Perf+", "gaming mode on"),
        ], spacing=10),
        ft.Container(height=10),
        ft.Text("Quick Info", size=14, weight=ft.FontWeight.BOLD, color=TEXT_MAIN),
        ft.Row([
            cmd_card(ft.icons.ACCESS_TIME, "Time", "Abhi kya baje", "time kya hua"),
            cmd_card(ft.icons.CALENDAR_TODAY, "Date", "Aaj ki tareekh", "date kya hai"),
            cmd_card(ft.icons.POWER_SETTINGS_NEW, "Shutdown", "1 min me", "shutdown"),
        ], spacing=10),
    ], spacing=10, scroll=ft.ScrollMode.AUTO)

    commands_tab = ft.Container(
        content=ft.Column([
            ft.Container(
                content=ft.Column([
                    ft.Text("Commands", size=18, weight=ft.FontWeight.BOLD, color=TEXT_MAIN),
                    ft.Text("Tap karo, JARVIS khud chalayega", size=11, color=TEXT_DIM),
                ], spacing=2),
                padding=ft.padding.symmetric(horizontal=20, vertical=12),
                bgcolor=BG_MID,
                border=ft.border.only(bottom=ft.border.BorderSide(1, "#1f2947")),
            ),
            ft.Container(content=commands_grid, padding=20, expand=True),
        ], spacing=0, expand=True),
        expand=True,
    )

    # =========================================================
    #   TAB 3: SETTINGS
    # =========================================================
    settings_tab = ft.Container(
        content=ft.Column([
            ft.Container(
                content=ft.Column([
                    ft.Text("Settings", size=18, weight=ft.FontWeight.BOLD, color=TEXT_MAIN),
                    ft.Text("App config", size=11, color=TEXT_DIM),
                ], spacing=2),
                padding=ft.padding.symmetric(horizontal=20, vertical=12),
                bgcolor=BG_MID,
                border=ft.border.only(bottom=ft.border.BorderSide(1, "#1f2947")),
            ),
            ft.Container(
                content=ft.Column([
                    _card(ft.Column([
                        ft.Text("Profile", size=13, weight=ft.FontWeight.BOLD, color=TEXT_MAIN),
                        ft.Divider(height=1, color="#1f2947"),
                        ft.Row([ft.Text("Name", size=12, color=TEXT_DIM),
                                ft.Container(expand=True),
                                ft.Text(USER_NAME, size=12, color=TEXT_MAIN)]),
                        ft.Row([ft.Text("City", size=12, color=TEXT_DIM),
                                ft.Container(expand=True),
                                ft.Text(USER_CITY, size=12, color=TEXT_MAIN)]),
                        ft.Row([ft.Text("Project", size=12, color=TEXT_DIM),
                                ft.Container(expand=True),
                                ft.Text(USER_PROJECT, size=12, color=TEXT_MAIN)]),
                    ], spacing=8)),
                    ft.Container(height=10),
                    _card(ft.Column([
                        ft.Text("AI Model", size=13, weight=ft.FontWeight.BOLD, color=TEXT_MAIN),
                        ft.Divider(height=1, color="#1f2947"),
                        ft.Row([ft.Text("Provider", size=12, color=TEXT_DIM),
                                ft.Container(expand=True),
                                ft.Text("Groq", size=12, color=SUCCESS)]),
                        ft.Row([ft.Text("Model", size=12, color=TEXT_DIM),
                                ft.Container(expand=True),
                                ft.Text("llama-3.3-70b", size=12, color=TEXT_MAIN)]),
                        ft.Row([ft.Text("Status", size=12, color=TEXT_DIM),
                                ft.Container(expand=True),
                                ft.Text("Connected ✅" if brain.client else "Offline ❌",
                                        size=12, color=SUCCESS if brain.client else DANGER)]),
                    ], spacing=8)),
                    ft.Container(height=10),
                    _card(ft.Column([
                        ft.Text("Voice", size=13, weight=ft.FontWeight.BOLD, color=TEXT_MAIN),
                        ft.Divider(height=1, color="#1f2947"),
                        ft.Row([ft.Text("Voice Mode", size=12, color=TEXT_DIM),
                                ft.Container(expand=True),
                                ft.Text("Male (pyttsx3)", size=12, color=TEXT_MAIN)]),
                        ft.Row([ft.Text("Wake Word", size=12, color=TEXT_DIM),
                                ft.Container(expand=True),
                                ft.Text(f'"{WAKE_WORD}"', size=12, color=ACCENT)]),
                        ft.Row([ft.Text("Language", size=12, color=TEXT_DIM),
                                ft.Container(expand=True),
                                ft.Text("Urdu / English", size=12, color=TEXT_MAIN)]),
                    ], spacing=8)),
                ], spacing=10, scroll=ft.ScrollMode.AUTO),
                padding=20, expand=True,
            ),
        ], spacing=0, expand=True),
        expand=True,
    )

    # =========================================================
    #   TAB 4: ABOUT
    # =========================================================
    about_tab = ft.Container(
        content=ft.Column([
            ft.Container(
                content=ft.Column([
                    ft.Text("About", size=18, weight=ft.FontWeight.BOLD, color=TEXT_MAIN),
                    ft.Text("JARVIS ke baare me", size=11, color=TEXT_DIM),
                ], spacing=2),
                padding=ft.padding.symmetric(horizontal=20, vertical=12),
                bgcolor=BG_MID,
                border=ft.border.only(bottom=ft.border.BorderSide(1, "#1f2947")),
            ),
            ft.Container(
                content=ft.Column([
                    ft.Container(
                        content=ft.Column([
                            ft.Container(
                                content=ft.Icon(ft.icons.SMART_TOY, color=ACCENT, size=40),
                                bgcolor=BG_LIGHT, padding=20, border_radius=60,
                                border=ft.border.all(2, ACCENT),
                            ),
                            ft.Text("JARVIS", size=26, weight=ft.FontWeight.BOLD, color=TEXT_MAIN),
                            ft.Text("Dina Wala • Aura 99999+", size=12, color=TEXT_DIM),
                            ft.Text("Version 1.0.0", size=11, color=TEXT_MUTED),
                        ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=6),
                        padding=30,
                        alignment=ft.alignment.center,
                    ),
                    ft.Row([
                        _stat_tile(ft.icons.BOLT, "AI Model", "Llama 3.3", SUCCESS),
                        _stat_tile(ft.icons.MIC, "Voice", "STT+TTS", WARNING),
                        _stat_tile(ft.icons.TERMINAL, "Commands", "10+", ACCENT),
                    ], spacing=10),
                    ft.Container(height=15),
                    _card(ft.Column([
                        ft.Text("Features", size=13, weight=ft.FontWeight.BOLD, color=TEXT_MAIN),
                        ft.Divider(height=1, color="#1f2947"),
                        ft.Text("✅  AI Chat (Groq Llama 3.3 70B)", size=12, color=TEXT_MAIN),
                        ft.Text("✅  Voice Input (mic se sunna)", size=12, color=TEXT_MAIN),
                        ft.Text("✅  Voice Output (bolna)", size=12, color=TEXT_MAIN),
                        ft.Text("✅  Memory (purani baat yaad)", size=12, color=TEXT_MAIN),
                        ft.Text("✅  App Open/Close control", size=12, color=TEXT_MAIN),
                        ft.Text("✅  Volume / Brightness control", size=12, color=TEXT_MAIN),
                        ft.Text("✅  Gaming Mode", size=12, color=TEXT_MAIN),
                        ft.Text("✅  Time / Date local commands", size=12, color=TEXT_MAIN),
                        ft.Text("✅  Offline fallback", size=12, color=TEXT_MAIN),
                    ], spacing=6)),
                    ft.Container(height=10),
                    _card(ft.Column([
                        ft.Text("Tech Stack", size=13, weight=ft.FontWeight.BOLD, color=TEXT_MAIN),
                        ft.Divider(height=1, color="#1f2947"),
                        ft.Text("🐍  Python 3.11", size=12, color=TEXT_MAIN),
                        ft.Text("🎨  Flet (Flutter UI)", size=12, color=TEXT_MAIN),
                        ft.Text("🧠  Groq API (Llama 3.3)", size=12, color=TEXT_MAIN),
                        ft.Text("🎤  SpeechRecognition + pyttsx3", size=12, color=TEXT_MAIN),
                    ], spacing=6)),
                    ft.Container(height=15),
                    ft.Container(
                        content=ft.Text("Made with ❤️ in Dina", size=12, color=ACCENT,
                                        weight=ft.FontWeight.BOLD),
                        alignment=ft.alignment.center,
                    ),
                ], spacing=10, scroll=ft.ScrollMode.AUTO),
                padding=20, expand=True,
            ),
        ], spacing=0, expand=True),
        expand=True,
    )

    # =========================================================
    #   TAB SWITCHING
    # =========================================================
    content_area = ft.Container(expand=True)

    tabs = {0: chat_tab, 1: commands_tab, 2: settings_tab, 3: about_tab}

    def switch_tab(idx):
        state.current_tab = idx
        content_area.content = tabs[idx]
        refresh_nav()

    # Initialize
    content_area.content = chat_tab
    refresh_nav()

    # =========================================================
    #   LAYOUT (Sidebar + Content)
    # =========================================================
    page.add(ft.Row([
        sidebar,
        ft.Container(content=content_area, expand=True, bgcolor=BG_DARK),
    ], spacing=0, expand=True))


if __name__ == "__main__":
    ft.app(target=main, assets_dir="assets")
